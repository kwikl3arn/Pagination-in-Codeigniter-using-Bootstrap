<html lang="id">
<head>
	<meta charset="utf-8">
	<title>Animal Report</title>
	<!--Load file bootstrap.css-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.css'?>">
</head>
<body>

<div class="container">
	<h1>Animal <strong>Report</strong></h1>

	<table class="table table-striped">
		<thead>
			<tr>
				<th>Type</th>
				<th>Id</th>
				<th>Dam_no</th>
			</tr>
		</thead>
		<tbody>
			<!--Fetch data from the database-->
            <?php foreach ($data->result() as $row) :?>
                <tr>
                    <td><?php echo $row->animal_type; ?></td>
                    <td><?php echo $row->animal_id; ?></td>
                    <td><?php echo $row->dam_no; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
	</table>
    <div class="row">
    	<div class="col">
    		<!--Show pagination-->
    		<?php echo $pagination; ?>
    	</div>
    </div>
     

</div>
<!--Load file bootstrap.js-->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.js"></script>
</body>
</html>