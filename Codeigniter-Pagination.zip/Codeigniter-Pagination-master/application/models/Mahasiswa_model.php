<?php
class Mahasiswa_model extends CI_Model{
   
    //retrieve student data from the database
    function get_mahasiswa_list($limit, $start){
        $query = $this->db->get('animal_master', $limit, $start);
        return $query;
    }
}